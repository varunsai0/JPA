package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Mobile;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	     EntityManager manager=factory.createEntityManager();
	     manager.getTransaction().begin();
	     
	     Mobile mobile=new Mobile();
	     mobile.setMobileName("iPhone");
	     mobile.setMobileNumber(9879879876l);
	     manager.persist(mobile);
	     
	     Mobile mobile1=new Mobile();
	     mobile1.setMobileName("honor");
	     mobile1.setMobileNumber(7896543212l);
	     manager.persist(mobile1);
	     
	     manager.close();
	     System.out.println("Added mobile");
	     manager.getTransaction().commit();
	     factory.close();
	}

}
