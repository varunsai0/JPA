package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Mobile;

public class UpdateMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		
		Mobile obj=em.find(Mobile.class, 1);
		System.out.println("Original object="+obj);
		obj.setMobileName(obj.getMobileName()+" India");
	
		em.merge(obj);
		em.getTransaction().commit();
		em.close();
		System.out.println("updated");
		factory.close();

	}

}
