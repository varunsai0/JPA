package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="mobile")
public class Mobile {
     @Id
     @GeneratedValue(generator="my_seq")
     @SequenceGenerator(name="my_seq",sequenceName="MY_SEQ",allocationSize=1)
	private int mobileId;
	private String mobileName;
	private Long mobileNumber;
	
	
	public Mobile() {
		// TODO Auto-generated constructor stub
	}

	public Mobile(int mobileId, String mobileName, Long mobileNumber) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.mobileNumber = mobileNumber;
	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mobileName=" + mobileName + ", mobileNumber=" + mobileNumber + "]";
	}
	
	
	
}
