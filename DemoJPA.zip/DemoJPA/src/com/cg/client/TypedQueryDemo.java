package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.entity.Employee;

public class TypedQueryDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	     EntityManager manager=factory.createEntityManager();
	     manager.getTransaction().begin();
	     
	     String qry="Select emp from Employee emp where emp.empSal>=20000 and emp.empSal<=40000 ";
       TypedQuery<Employee> query=manager.createQuery(qry, Employee.class);
       List list=query.getResultList();
	     for(Object obj:list) {
	    	 
	    	/* ((Employee)obj).getEmpId();*/
	    	 System.out.println(obj);
	     }
	     manager.getTransaction().commit();
	     manager.close();
	     factory.close();

	}

}
